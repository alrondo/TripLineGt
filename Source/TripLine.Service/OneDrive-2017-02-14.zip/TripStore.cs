﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using TripLine.Dtos;

namespace TripLine.Service
{

    public class TripStore
    {
        private readonly LocationService _locationService;
        private readonly PhotoStore _photoStore;
        private readonly TripSmartBuilder _smartBuilder;

        private readonly TripsRepo _tripRepo;


        public TripStore(PhotoStore photoStore, LocationService locationService, TripSmartBuilder smartBuilder, TripsRepo tripRepo)
        {
            _photoStore = photoStore;
            _locationService = locationService;
            _smartBuilder = smartBuilder;
        }

        public IEnumerable<TripCandidate> DetectNewTrips(List<PhotoSession> photoSessions)
        {
            _smartBuilder.Build(photoSessions);
            return _smartBuilder.BuildedTrips;
        }


        public void AddNewTrips(List<TripCandidate> tripCandidates)
        {
            List<Trip> trips = tripCandidates.Select(c => CreateTrip(c)).ToList();
            _tripRepo.Content.Trips.AddRange(trips);

            _tripRepo.Save();
        }

        public void AddNewTrip(TripCandidate tripCandidate)
        {
            Trip trip= CreateTrip(tripCandidate);
            _tripRepo.Content.Trips.Add(trip);

            _tripRepo.Save();
        }




        public Trip CreateTrip(TripCandidate tripCandidate)
        {
            Trip trip = AutoMapper.Mapper.Map<Trip>(tripCandidate);

            foreach (var sessionId in tripCandidate.PhotoSessions.Select(s => s.SessionId))
            {
                int? destinationId = null;

                var destination =
                    tripCandidate.Destinations.FirstOrDefault(d => d.Sessions.Any(s => s.SessionId == sessionId));

                if (destination != null)
                    destinationId = destination.Id;

                _photoStore.SetPinForPhotoInSession(sessionId, trip.Id, destinationId);
            }

            return trip;
        }


    }

}
